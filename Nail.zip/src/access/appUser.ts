import type {
  Access,
  CollectionBeforeDeleteHook,
  CollectionBeforeValidateHook,
  CollectionSlug,
} from 'payload'

export const isAppUser = (user: unknown): user is { id: string | number; collection: 'users' } => {
  return Boolean(
    user &&
    typeof user === 'object' &&
    'collection' in user &&
    user.collection === 'users' &&
    'id' in user,
  )
}

export const appUserOnly: Access = ({ req }) => isAppUser(req.user)

export const ownDocuments: Access = ({ req }) => {
  if (!isAppUser(req.user)) return false
  return { owner: { equals: req.user.id } }
}

export const setOwner: CollectionBeforeValidateHook = ({ data, req, operation }) => {
  if (operation === 'create' && isAppUser(req.user)) {
    return { ...data, owner: req.user.id }
  }
  return data
}

const relationshipID = (value: unknown) => {
  if (typeof value === 'string' || typeof value === 'number') return value
  if (value && typeof value === 'object' && 'id' in value) {
    const relationID = value.id
    if (typeof relationID === 'string' || typeof relationID === 'number') return relationID
  }
  return null
}

export const validateOwnedRelationships = (
  relationships: { collection: CollectionSlug; field: string }[],
): CollectionBeforeValidateHook => {
  return async ({ data, req }) => {
    if (!data || !isAppUser(req.user)) return data

    await Promise.all(
      relationships.map(async ({ collection, field }) => {
        const relationID = relationshipID(data[field])
        if (!relationID) return
        await req.payload.findByID({
          collection,
          id: relationID,
          user: req.user,
          overrideAccess: false,
        })
      }),
    )
    return data
  }
}

export const preventDeleteWhenReferenced = (
  collection: CollectionSlug,
  field: string,
  message: string,
): CollectionBeforeDeleteHook => {
  return async ({ id, req }) => {
    if (!isAppUser(req.user)) return
    const result = await req.payload.count({
      collection,
      user: req.user,
      overrideAccess: false,
      where: { [field]: { equals: id } },
    })
    if (result.totalDocs > 0) throw new Error(message)
  }
}
