'use server'

import config from '@payload-config'
import { getPayload } from 'payload'
import { getCurrentUser } from '@/lib/app-auth'

export type ActionResult = {
  ok: boolean
  message: string
}

const text = (data: FormData, key: string, max = 200) => {
  const value = String(data.get(key) ?? '').trim()
  if (!value || value.length > max) throw new Error(`Preencha ${key} corretamente.`)
  return value
}

const optionalText = (data: FormData, key: string, max = 500) => {
  const value = String(data.get(key) ?? '').trim()
  if (value.length > max) throw new Error(`${key} é muito longo.`)
  return value || undefined
}

const number = (data: FormData, key: string, min = 0) => {
  const value = Number(data.get(key))
  if (!Number.isFinite(value) || value < min)
    throw new Error(`Informe um valor válido para ${key}.`)
  return value
}

const id = (data: FormData, key = 'id') => {
  const value = String(data.get(key) ?? '').trim()
  if (!value) throw new Error('Registro inválido.')
  return value
}

const isoDate = (data: FormData, key: string) => {
  const value = String(data.get(key) ?? '')
  const date = new Date(value)
  if (!value || Number.isNaN(date.getTime())) throw new Error('Informe uma data válida.')
  return date.toISOString()
}

const choice = <T extends string>(data: FormData, key: string, allowed: readonly T[]): T => {
  const value = String(data.get(key) ?? '') as T
  if (!allowed.includes(value)) throw new Error(`Opção inválida para ${key}.`)
  return value
}

type UserContext = NonNullable<Awaited<ReturnType<typeof contextForUser>>>

async function withUser<T>(operation: (context: UserContext) => Promise<T>) {
  const context = await contextForUser()
  if (!context) throw new Error('Sua sessão expirou. Entre novamente.')
  return operation(context)
}

async function contextForUser() {
  const user = await getCurrentUser()
  if (!user) return null
  return { user, payload: await getPayload({ config }) }
}

const fail = (error: unknown): ActionResult => ({
  ok: false,
  message: error instanceof Error ? error.message : 'Não foi possível concluir a ação.',
})

export async function saveProfileAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      await payload.update({
        collection: 'users',
        id: user.id,
        user,
        overrideAccess: false,
        data: {
          name: text(data, 'name', 100),
          studioName: text(data, 'studioName', 120),
          phone: optionalText(data, 'phone', 30),
          instagram: optionalText(data, 'instagram', 80),
          bio: optionalText(data, 'bio', 500),
        },
      })
    })
    return { ok: true, message: 'Perfil atualizado.' }
  } catch (error) {
    return fail(error)
  }
}

export async function saveClientAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      const record = {
        name: text(data, 'name', 100),
        phone: text(data, 'phone', 30),
        email: optionalText(data, 'email', 160),
        preferences: optionalText(data, 'preferences', 500),
        notes: optionalText(data, 'notes', 800),
      }
      const recordId = String(data.get('id') ?? '')
      if (recordId)
        await payload.update({
          collection: 'clients',
          id: recordId,
          data: record,
          user,
          overrideAccess: false,
        })
      else
        await payload.create({
          collection: 'clients',
          data: { ...record, owner: user.id },
          user,
          overrideAccess: false,
        })
    })
    return { ok: true, message: 'Cliente salva com sucesso.' }
  } catch (error) {
    return fail(error)
  }
}

export async function deleteClientAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(({ payload, user }) =>
      payload.delete({ collection: 'clients', id: id(data), user, overrideAccess: false }),
    )
    return { ok: true, message: 'Cliente removida.' }
  } catch {
    return { ok: false, message: 'Não é possível remover uma cliente vinculada a agendamentos.' }
  }
}

export async function saveServiceAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      const record = {
        name: text(data, 'name', 100),
        category: text(data, 'category', 80),
        durationMinutes: number(data, 'durationMinutes', 5),
        price: number(data, 'price'),
        description: optionalText(data, 'description', 500),
        active: data.get('active') === 'on',
      }
      const recordId = String(data.get('id') ?? '')
      if (recordId)
        await payload.update({
          collection: 'services',
          id: recordId,
          data: record,
          user,
          overrideAccess: false,
        })
      else
        await payload.create({
          collection: 'services',
          data: { ...record, owner: user.id },
          user,
          overrideAccess: false,
        })
    })
    return { ok: true, message: 'Serviço salvo.' }
  } catch (error) {
    return fail(error)
  }
}

export async function deleteServiceAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(({ payload, user }) =>
      payload.delete({ collection: 'services', id: id(data), user, overrideAccess: false }),
    )
    return { ok: true, message: 'Serviço removido.' }
  } catch {
    return { ok: false, message: 'Não é possível remover um serviço vinculado a agendamentos.' }
  }
}

export async function saveAppointmentAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      const clientId = id(data, 'client')
      const serviceId = id(data, 'service')
      const [client, service] = await Promise.all([
        payload.findByID({ collection: 'clients', id: clientId, user, overrideAccess: false }),
        payload.findByID({ collection: 'services', id: serviceId, user, overrideAccess: false }),
      ])
      const record = {
        title: `${client.name} — ${service.name}`,
        client: client.id,
        service: service.id,
        date: isoDate(data, 'date'),
        status: choice(data, 'status', ['confirmed', 'pending', 'completed', 'cancelled'] as const),
        paymentStatus: choice(data, 'paymentStatus', ['pending', 'partial', 'paid'] as const),
        paymentMethod: choice(data, 'paymentMethod', [
          'pix',
          'dinheiro',
          'cartao',
          'transferencia',
          'outro',
        ] as const),
        amount: number(data, 'amount'),
        notes: optionalText(data, 'notes', 800),
      }
      const recordId = String(data.get('id') ?? '')
      const appointment = recordId
        ? await payload.update({
            collection: 'appointments',
            id: recordId,
            data: record,
            user,
            overrideAccess: false,
          })
        : await payload.create({
            collection: 'appointments',
            data: { ...record, owner: user.id },
            user,
            overrideAccess: false,
          })

      const linked = await payload.find({
        collection: 'financial-transactions',
        user,
        overrideAccess: false,
        limit: 1,
        where: { appointment: { equals: appointment.id } },
      })
      const financialData = {
        description: `Atendimento — ${client.name} — ${service.name}`,
        type: 'income' as const,
        category: 'servico' as const,
        amount: record.amount,
        transactionDate: record.date,
        status: record.paymentStatus === 'paid' ? ('paid' as const) : ('pending' as const),
        paymentMethod: record.paymentMethod,
        appointment: appointment.id,
      }
      if (linked.docs[0]) {
        await payload.update({
          collection: 'financial-transactions',
          id: linked.docs[0].id,
          data: financialData,
          user,
          overrideAccess: false,
        })
      } else {
        await payload.create({
          collection: 'financial-transactions',
          data: { ...financialData, owner: user.id },
          user,
          overrideAccess: false,
        })
      }
    })
    return { ok: true, message: 'Agendamento salvo.' }
  } catch (error) {
    return fail(error)
  }
}

export async function deleteAppointmentAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(({ payload, user }) =>
      payload.delete({ collection: 'appointments', id: id(data), user, overrideAccess: false }),
    )
    return { ok: true, message: 'Agendamento removido.' }
  } catch (error) {
    return fail(error)
  }
}

export async function saveProductAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      const record = {
        name: text(data, 'name', 120),
        category: text(data, 'category', 80),
        brand: optionalText(data, 'brand', 80),
        unit: choice(data, 'unit', ['un', 'ml', 'g', 'caixa'] as const),
        currentStock: number(data, 'currentStock'),
        minimumStock: number(data, 'minimumStock'),
        costPrice: number(data, 'costPrice'),
        supplier: optionalText(data, 'supplier', 120),
      }
      const recordId = String(data.get('id') ?? '')
      if (recordId)
        await payload.update({
          collection: 'products',
          id: recordId,
          data: record,
          user,
          overrideAccess: false,
        })
      else
        await payload.create({
          collection: 'products',
          data: { ...record, owner: user.id },
          user,
          overrideAccess: false,
        })
    })
    return { ok: true, message: 'Produto salvo no estoque.' }
  } catch (error) {
    return fail(error)
  }
}

export async function deleteProductAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(({ payload, user }) =>
      payload.delete({ collection: 'products', id: id(data), user, overrideAccess: false }),
    )
    return { ok: true, message: 'Produto removido.' }
  } catch {
    return { ok: false, message: 'Produtos com movimentações não podem ser removidos.' }
  }
}

export async function createStockMovementAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      const productId = id(data, 'product')
      const product = await payload.findByID({
        collection: 'products',
        id: productId,
        user,
        overrideAccess: false,
      })
      const type = choice(data, 'type', ['in', 'out', 'adjustment'] as const)
      const quantity = number(data, 'quantity', 0.01)
      const nextStock =
        type === 'in'
          ? product.currentStock + quantity
          : type === 'out'
            ? product.currentStock - quantity
            : quantity
      if (nextStock < 0) throw new Error('A saída é maior que o estoque disponível.')

      await payload.create({
        collection: 'stock-movements',
        user,
        overrideAccess: false,
        data: {
          owner: user.id,
          product: product.id,
          type,
          quantity,
          unitCost: number(data, 'unitCost'),
          movementDate: isoDate(data, 'movementDate'),
          description: text(data, 'description', 180),
        },
      })
      await payload.update({
        collection: 'products',
        id: product.id,
        user,
        overrideAccess: false,
        data: { currentStock: nextStock },
      })
      if (type === 'in' && data.get('recordExpense') === 'on') {
        await payload.create({
          collection: 'financial-transactions',
          user,
          overrideAccess: false,
          data: {
            owner: user.id,
            description: `Compra de estoque — ${product.name}`,
            type: 'expense',
            category: 'materiais',
            amount: quantity * number(data, 'unitCost'),
            transactionDate: isoDate(data, 'movementDate'),
            status: 'paid',
            paymentMethod: choice(data, 'paymentMethod', [
              'pix',
              'dinheiro',
              'cartao',
              'transferencia',
              'outro',
            ] as const),
          },
        })
      }
    })
    return { ok: true, message: 'Movimentação registrada e saldo atualizado.' }
  } catch (error) {
    return fail(error)
  }
}

export async function saveFinancialTransactionAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(async ({ payload, user }) => {
      const record = {
        description: text(data, 'description', 180),
        type: choice(data, 'type', ['income', 'expense'] as const),
        category: choice(data, 'category', [
          'servico',
          'produto',
          'materiais',
          'aluguel',
          'contas',
          'marketing',
          'outros',
        ] as const),
        amount: number(data, 'amount', 0.01),
        transactionDate: isoDate(data, 'transactionDate'),
        status: choice(data, 'transactionStatus', ['paid', 'pending'] as const),
        paymentMethod: choice(data, 'paymentMethod', [
          'pix',
          'dinheiro',
          'cartao',
          'transferencia',
          'outro',
        ] as const),
        notes: optionalText(data, 'notes', 800),
      }
      const recordId = String(data.get('id') ?? '')
      if (recordId)
        await payload.update({
          collection: 'financial-transactions',
          id: recordId,
          data: record,
          user,
          overrideAccess: false,
        })
      else
        await payload.create({
          collection: 'financial-transactions',
          data: { ...record, owner: user.id },
          user,
          overrideAccess: false,
        })
    })
    return { ok: true, message: 'Lançamento financeiro salvo.' }
  } catch (error) {
    return fail(error)
  }
}

export async function markTransactionPaidAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(({ payload, user }) =>
      payload.update({
        collection: 'financial-transactions',
        id: id(data),
        user,
        overrideAccess: false,
        data: { status: 'paid' },
      }),
    )
    return { ok: true, message: 'Pagamento marcado como pago.' }
  } catch (error) {
    return fail(error)
  }
}

export async function deleteFinancialTransactionAction(data: FormData): Promise<ActionResult> {
  try {
    await withUser(({ payload, user }) =>
      payload.delete({
        collection: 'financial-transactions',
        id: id(data),
        user,
        overrideAccess: false,
      }),
    )
    return { ok: true, message: 'Lançamento removido.' }
  } catch (error) {
    return fail(error)
  }
}
