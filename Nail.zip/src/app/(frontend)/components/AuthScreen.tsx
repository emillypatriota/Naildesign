'use client'

import { useState, useTransition, type FormEvent } from 'react'
import { ArrowRight, Eye, EyeOff, LockKeyhole, Sparkles } from 'lucide-react'
import { ThemeToggle } from './ThemeToggle'

export function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [showPassword, setShowPassword] = useState(false)
  const [message, setMessage] = useState('')
  const [pending, startTransition] = useTransition()

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    startTransition(async () => {
      try {
        const response = await fetch(
          mode === 'login' ? '/auth/session/login' : '/auth/session/signup',
          { method: 'POST', body: data },
        )
        const result = (await response.json()) as { ok: boolean; message: string }
        setMessage(result.message)
        if (result.ok) window.location.assign('/')
      } catch {
        setMessage('Não foi possível conectar. Tente novamente em instantes.')
      }
    })
  }

  return (
    <main className="auth-shell flex min-h-screen items-center justify-center px-4 py-10">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-[-20rem] size-[45rem] -translate-x-1/2 rounded-full bg-[#d62e76]/10 blur-[120px]" />
      </div>
      <div className="absolute right-5 top-5 z-10">
        <ThemeToggle />
      </div>
      <section className="auth-card relative w-full max-w-md rounded-3xl p-7 shadow-2xl sm:p-9">
        <div className="mb-8 flex items-center gap-3">
          <span className="flex size-11 items-center justify-center rounded-full border border-[#d62e76]/50 bg-[#25131c] font-serif text-2xl italic text-[#ef5a9a]">
            A
          </span>
          <div>
            <p className="font-serif text-xl">Andrade</p>
            <p className="text-[8px] uppercase tracking-[.3em] text-[#857b80]">Nails Studio</p>
          </div>
        </div>
        <div className="mb-7">
          <p className="mb-2 flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.22em] text-[#dc3a7b]">
            <Sparkles size={12} /> Gestão inteligente
          </p>
          <h1 className="font-serif text-3xl">
            {mode === 'login' ? 'Bem-vinda de volta.' : 'Crie seu espaço.'}
          </h1>
          <p className="mt-2 text-sm leading-6 text-[#81787c]">
            {mode === 'login'
              ? 'Entre para cuidar da sua agenda, estoque e financeiro.'
              : 'Comece a organizar seu estúdio em poucos minutos.'}
          </p>
        </div>
        <form onSubmit={submit} className="space-y-4">
          {mode === 'signup' && (
            <>
              <Field label="Seu nome">
                <input name="name" required placeholder="Gabriela Andrade" />
              </Field>
              <Field label="Nome do estúdio">
                <input name="studioName" required defaultValue="Andrade Nails Studio" />
              </Field>
            </>
          )}
          <Field label="E-mail">
            <input name="email" type="email" required placeholder="voce@exemplo.com" />
          </Field>
          <Field label="Senha">
            <div className="relative">
              <input
                name="password"
                type={showPassword ? 'text' : 'password'}
                required
                minLength={8}
                placeholder="Mínimo de 8 caracteres"
                className="pr-12"
              />
              <button
                type="button"
                aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                onClick={() => setShowPassword((value) => !value)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#736a6e] hover:text-white"
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
          </Field>
          {message && (
            <p className="rounded-lg border border-[#d62e76]/20 bg-[#24131b] px-3 py-2 text-xs text-[#e9a1bf]">
              {message}
            </p>
          )}
          <button
            disabled={pending}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#d62e76] py-3.5 text-sm font-semibold hover:bg-[#e33a80] disabled:opacity-60"
          >
            <LockKeyhole size={16} />{' '}
            {pending ? 'Aguarde...' : mode === 'login' ? 'Entrar no painel' : 'Criar minha conta'}{' '}
            <ArrowRight size={16} />
          </button>
        </form>
        <button
          type="button"
          onClick={() => {
            setMode((value) => (value === 'login' ? 'signup' : 'login'))
            setMessage('')
          }}
          className="mt-6 w-full text-center text-xs text-[#857d80] hover:text-white"
        >
          {mode === 'login' ? 'Primeiro acesso? Criar conta' : 'Já possui uma conta? Entrar'}
        </button>
      </section>
    </main>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="auth-field">
      <span>{label}</span>
      {children}
    </label>
  )
}
