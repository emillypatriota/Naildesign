'use client'

import { Moon, Sun } from 'lucide-react'
import { useEffect, useState } from 'react'

type Theme = 'dark' | 'light'

export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const [theme, setTheme] = useState<Theme>('dark')

  useEffect(() => {
    setTheme(document.documentElement.dataset.theme === 'light' ? 'light' : 'dark')
  }, [])

  function toggle() {
    const next: Theme = theme === 'dark' ? 'light' : 'dark'
    document.documentElement.dataset.theme = next
    localStorage.setItem('andrade-theme', next)
    setTheme(next)
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={theme === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro'}
      title={theme === 'dark' ? 'Modo claro' : 'Modo escuro'}
      className={compact ? 'theme-toggle theme-toggle-compact' : 'theme-toggle'}
    >
      <span className={theme === 'light' ? 'theme-option theme-option-active' : 'theme-option'}>
        <Sun size={15} />
        {!compact && 'Claro'}
      </span>
      <span className={theme === 'dark' ? 'theme-option theme-option-active' : 'theme-option'}>
        <Moon size={15} />
        {!compact && 'Escuro'}
      </span>
    </button>
  )
}
