import config from '@payload-config'
import { cookies } from 'next/headers'
import { getPayload } from 'payload'

const SESSION_COOKIE = 'app-session'

export async function getCurrentUser() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value
  if (!token) return null

  const payload = await getPayload({ config })
  const authHeaders = new Headers({ Authorization: `JWT ${token}` })
  const { user } = await payload.auth({ headers: authHeaders })
  if (!user || user.collection !== 'users') return null
  return user
}

export async function createAppSession(email: string, password: string) {
  const payload = await getPayload({ config })
  const result = await payload.login({
    collection: 'users',
    data: { email, password },
    overrideAccess: false,
  })
  if (!result.token || !result.user) throw new Error('Não foi possível iniciar a sessão.')

  const cookieStore = await cookies()
  const embeddedSecureContext = process.env.FIGMA === '1' || process.env.NODE_ENV === 'production'
  cookieStore.set(SESSION_COOKIE, result.token, {
    httpOnly: true,
    sameSite: embeddedSecureContext ? 'none' : 'lax',
    secure: embeddedSecureContext,
    path: '/',
    maxAge: result.exp
      ? Math.max(result.exp - Math.floor(Date.now() / 1000), 60)
      : 60 * 60 * 24 * 7,
  })
  return result.user
}

export async function clearAppSession() {
  const cookieStore = await cookies()
  cookieStore.delete(SESSION_COOKIE)
}
