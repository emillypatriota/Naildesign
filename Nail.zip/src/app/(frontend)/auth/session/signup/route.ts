import config from '@payload-config'
import { getPayload } from 'payload'
import { createAppSession } from '@/lib/app-auth'

export async function POST(request: Request) {
  try {
    const data = await request.formData()
    const name = String(data.get('name') ?? '').trim()
    const studioName = String(data.get('studioName') ?? '').trim()
    const email = String(data.get('email') ?? '')
      .trim()
      .toLowerCase()
    const password = String(data.get('password') ?? '')
    if (!name || !studioName || !email) {
      return Response.json({ ok: false, message: 'Preencha todos os campos.' }, { status: 400 })
    }
    if (password.length < 8) {
      return Response.json(
        { ok: false, message: 'A senha precisa ter pelo menos 8 caracteres.' },
        { status: 400 },
      )
    }
    const payload = await getPayload({ config })
    await payload.create({
      collection: 'users',
      overrideAccess: false,
      data: { name, studioName, email, password },
    })
    await createAppSession(email, password)
    return Response.json({ ok: true, message: 'Conta criada com sucesso.' })
  } catch {
    return Response.json(
      { ok: false, message: 'Este e-mail já possui uma conta. Tente entrar.' },
      { status: 409 },
    )
  }
}
