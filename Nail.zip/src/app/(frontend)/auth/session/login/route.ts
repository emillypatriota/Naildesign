import { createAppSession } from '@/lib/app-auth'

export async function POST(request: Request) {
  try {
    const data = await request.formData()
    const email = String(data.get('email') ?? '')
      .trim()
      .toLowerCase()
    const password = String(data.get('password') ?? '')
    if (!email || !password) {
      return Response.json({ ok: false, message: 'Preencha e-mail e senha.' }, { status: 400 })
    }
    await createAppSession(email, password)
    return Response.json({ ok: true, message: 'Login realizado com sucesso.' })
  } catch {
    return Response.json(
      { ok: false, message: 'E-mail ou senha incorretos. Confira os dados e tente novamente.' },
      { status: 401 },
    )
  }
}
