import type { CollectionConfig } from 'payload'
import { isAppUser } from '@/access/appUser'

export const Users: CollectionConfig = {
  slug: 'users',
  auth: true,
  admin: {
    hidden: true,
    useAsTitle: 'name',
  },
  access: {
    create: () => true,
    read: ({ req }) => (isAppUser(req.user) ? { id: { equals: req.user.id } } : false),
    update: ({ req }) => (isAppUser(req.user) ? { id: { equals: req.user.id } } : false),
    delete: () => false,
  },
  fields: [
    { name: 'name', type: 'text', required: true },
    { name: 'studioName', type: 'text', required: true, defaultValue: 'Andrade Nails Studio' },
    { name: 'phone', type: 'text' },
    { name: 'instagram', type: 'text' },
    { name: 'bio', type: 'textarea' },
  ],
}
