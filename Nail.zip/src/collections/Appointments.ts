import type { CollectionConfig } from 'payload'
import {
  appUserOnly,
  ownDocuments,
  preventDeleteWhenReferenced,
  setOwner,
  validateOwnedRelationships,
} from '@/access/appUser'

export const Appointments: CollectionConfig = {
  slug: 'appointments',
  admin: {
    group: 'Estúdio',
    useAsTitle: 'title',
    defaultColumns: ['title', 'date', 'status', 'paymentStatus'],
  },
  access: { create: appUserOnly, read: ownDocuments, update: ownDocuments, delete: ownDocuments },
  hooks: {
    beforeValidate: [
      setOwner,
      validateOwnedRelationships([
        { field: 'client', collection: 'clients' },
        { field: 'service', collection: 'services' },
      ]),
    ],
    beforeDelete: [
      preventDeleteWhenReferenced(
        'financial-transactions',
        'appointment',
        'Este agendamento possui lançamentos financeiros vinculados.',
      ),
    ],
  },
  fields: [
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      index: true,
      admin: { hidden: true },
    },
    { name: 'title', type: 'text', required: true },
    { name: 'client', type: 'relationship', relationTo: 'clients', required: true },
    { name: 'service', type: 'relationship', relationTo: 'services', required: true },
    { name: 'date', type: 'date', required: true, index: true },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'confirmed',
      options: [
        { label: 'Confirmado', value: 'confirmed' },
        { label: 'Pendente', value: 'pending' },
        { label: 'Concluído', value: 'completed' },
        { label: 'Cancelado', value: 'cancelled' },
      ],
    },
    {
      name: 'paymentStatus',
      type: 'select',
      required: true,
      defaultValue: 'pending',
      options: [
        { label: 'Pendente', value: 'pending' },
        { label: 'Parcial', value: 'partial' },
        { label: 'Pago', value: 'paid' },
      ],
    },
    {
      name: 'paymentMethod',
      type: 'select',
      options: ['pix', 'dinheiro', 'cartao', 'transferencia', 'outro'],
    },
    { name: 'amount', type: 'number', required: true, min: 0 },
    { name: 'notes', type: 'textarea' },
  ],
}
