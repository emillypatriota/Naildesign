import type { CollectionConfig } from 'payload'
import { appUserOnly, ownDocuments, preventDeleteWhenReferenced, setOwner } from '@/access/appUser'

export const Clients: CollectionConfig = {
  slug: 'clients',
  admin: { group: 'Estúdio', useAsTitle: 'name', defaultColumns: ['name', 'phone', 'lastVisit'] },
  access: { create: appUserOnly, read: ownDocuments, update: ownDocuments, delete: ownDocuments },
  hooks: {
    beforeValidate: [setOwner],
    beforeDelete: [
      preventDeleteWhenReferenced(
        'appointments',
        'client',
        'Esta cliente possui agendamentos vinculados.',
      ),
    ],
  },
  fields: [
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      index: true,
      admin: { hidden: true },
    },
    { name: 'name', type: 'text', required: true },
    { name: 'phone', type: 'text', required: true },
    { name: 'email', type: 'email' },
    { name: 'preferences', type: 'textarea' },
    { name: 'notes', type: 'textarea' },
    { name: 'visits', type: 'number', defaultValue: 0, min: 0 },
    { name: 'lastVisit', type: 'date' },
  ],
}
