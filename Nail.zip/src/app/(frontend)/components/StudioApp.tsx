'use client'

import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { useMemo, useState, useTransition, type ElementType, type FormEvent } from 'react'
import {
  ArrowDownLeft,
  ArrowUpRight,
  BadgeDollarSign,
  Bell,
  Box,
  CalendarDays,
  Camera,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  ContactRound,
  CreditCard,
  GalleryHorizontalEnd,
  Heart,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageCircle,
  PackageMinus,
  PackagePlus,
  Pencil,
  Plus,
  Search,
  Scissors,
  Send,
  Settings,
  ShoppingBasket,
  Sparkles,
  Trash2,
  TrendingDown,
  TrendingUp,
  UserRound,
  UsersRound,
  WalletCards,
  X,
} from 'lucide-react'
import {
  createStockMovementAction,
  deleteAppointmentAction,
  deleteClientAction,
  deleteFinancialTransactionAction,
  deleteProductAction,
  deleteServiceAction,
  markTransactionPaidAction,
  saveAppointmentAction,
  saveClientAction,
  saveFinancialTransactionAction,
  saveProductAction,
  saveProfileAction,
  saveServiceAction,
  type ActionResult,
} from '../actions'
import { ThemeToggle } from './ThemeToggle'

type Page =
  | 'dashboard'
  | 'agenda'
  | 'clientes'
  | 'servicos'
  | 'estoque'
  | 'financeiro'
  | 'galeria'
  | 'divulgar'
  | 'perfil'
type ModalKind =
  | 'appointment'
  | 'client'
  | 'service'
  | 'product'
  | 'movement'
  | 'transaction'
  | 'profile'
  | null

type UserData = {
  id: string
  name: string
  studioName: string
  email: string
  phone: string
  instagram: string
  bio: string
}
type ClientData = {
  id: string
  name: string
  phone: string
  email: string
  preferences: string
  notes: string
  visits: number
  lastVisit: string
}
type ServiceData = {
  id: string
  name: string
  category: string
  durationMinutes: number
  price: number
  description: string
  active: boolean
}
type AppointmentData = {
  id: string
  title: string
  clientId: string
  clientName: string
  serviceId: string
  serviceName: string
  date: string
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled'
  paymentStatus: 'pending' | 'partial' | 'paid'
  paymentMethod: 'pix' | 'dinheiro' | 'cartao' | 'transferencia' | 'outro'
  amount: number
  notes: string
}
type ProductData = {
  id: string
  name: string
  category: string
  brand: string
  unit: 'un' | 'ml' | 'g' | 'caixa'
  currentStock: number
  minimumStock: number
  costPrice: number
  supplier: string
}
type MovementData = {
  id: string
  productName: string
  type: 'in' | 'out' | 'adjustment'
  quantity: number
  unitCost: number
  movementDate: string
  description: string
}
type TransactionData = {
  id: string
  description: string
  type: 'income' | 'expense'
  category: 'servico' | 'produto' | 'materiais' | 'aluguel' | 'contas' | 'marketing' | 'outros'
  amount: number
  transactionDate: string
  status: 'paid' | 'pending'
  paymentMethod: 'pix' | 'dinheiro' | 'cartao' | 'transferencia' | 'outro'
  notes: string
}

export type StudioData = {
  user: UserData
  clients: ClientData[]
  services: ServiceData[]
  appointments: AppointmentData[]
  products: ProductData[]
  movements: MovementData[]
  transactions: TransactionData[]
}

const navItems: { id: Page; label: string; icon: ElementType }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'agenda', label: 'Agenda', icon: CalendarDays },
  { id: 'clientes', label: 'Clientes', icon: UsersRound },
  { id: 'servicos', label: 'Serviços e preços', icon: Scissors },
  { id: 'estoque', label: 'Estoque', icon: ShoppingBasket },
  { id: 'financeiro', label: 'Financeiro', icon: WalletCards },
  { id: 'galeria', label: 'Galeria de unhas', icon: GalleryHorizontalEnd },
]

const money = (value: number) =>
  value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const dateLabel = (value: string) =>
  new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }).format(
    new Date(value),
  )
const dateTimeInput = (value?: string) =>
  value
    ? new Date(new Date(value).getTime() - new Date(value).getTimezoneOffset() * 60000)
        .toISOString()
        .slice(0, 16)
    : new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16)

export function StudioApp({ initialData }: { initialData: StudioData }) {
  const router = useRouter()
  const [page, setPage] = useState<Page>('dashboard')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [modal, setModal] = useState<ModalKind>(null)
  const [editing, setEditing] = useState<unknown>(null)
  const [toast, setToast] = useState('')
  const [pending, startTransition] = useTransition()

  const openModal = (kind: ModalKind, value: unknown = null) => {
    setEditing(value)
    setModal(kind)
  }
  const closeModal = () => {
    setModal(null)
    setEditing(null)
  }
  const notify = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(''), 3000)
  }
  const navigate = (next: Page) => {
    setPage(next)
    setMobileMenu(false)
  }

  function runAction(
    action: (data: FormData) => Promise<ActionResult>,
    data: FormData,
    close = true,
  ) {
    startTransition(async () => {
      const result = await action(data)
      notify(result.message)
      if (result.ok) {
        if (close) closeModal()
        router.refresh()
      }
    })
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const actions = {
      appointment: saveAppointmentAction,
      client: saveClientAction,
      service: saveServiceAction,
      product: saveProductAction,
      movement: createStockMovementAction,
      transaction: saveFinancialTransactionAction,
      profile: saveProfileAction,
    }
    if (modal) runAction(actions[modal], data)
  }

  function remove(
    action: (data: FormData) => Promise<ActionResult>,
    recordId: string,
    label: string,
  ) {
    if (!window.confirm(`Deseja realmente remover ${label}?`)) return
    const data = new FormData()
    data.set('id', recordId)
    runAction(action, data, false)
  }

  function shareAgenda() {
    const message = `Agenda aberta no ${initialData.user.studioName}! Entre em contato para reservar seu horário.`
    if (navigator.share)
      navigator.share({ title: initialData.user.studioName, text: message }).catch(() => null)
    else
      navigator.clipboard.writeText(message).then(() => notify('Texto copiado para compartilhar.'))
  }

  return (
    <div className="studio-shell min-h-screen">
      <Sidebar
        page={page}
        user={initialData.user}
        open={mobileMenu}
        navigate={navigate}
        close={() => setMobileMenu(false)}
        logout={() =>
          startTransition(async () => {
            await fetch('/auth/session/logout', { method: 'POST' })
            window.location.assign('/')
          })
        }
      />
      <div className="lg:pl-[250px]">
        <header className="studio-header sticky top-0 z-30 flex h-[74px] items-center justify-between border-b px-4 backdrop-blur-xl sm:px-7 lg:px-9">
          <button
            type="button"
            aria-label="Abrir menu"
            onClick={() => setMobileMenu(true)}
            className="icon-btn lg:hidden"
          >
            <Menu size={18} />
          </button>
          <p className="hidden text-xs text-[#777074] sm:block">
            {initialData.user.studioName} <span className="mx-2 text-[#383437]">/</span> Painel de
            gestão
          </p>
          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle compact />
            <button
              type="button"
              aria-label="Ver avisos"
              onClick={() =>
                notify(
                  lowStockCount(initialData.products)
                    ? `${lowStockCount(initialData.products)} produto(s) com estoque baixo.`
                    : 'Tudo em dia. Nenhum aviso novo.',
                )
              }
              className="icon-btn relative"
            >
              <Bell size={18} />
              {lowStockCount(initialData.products) > 0 && (
                <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[#df3f81]" />
              )}
            </button>
            <button
              type="button"
              onClick={() => openModal('appointment')}
              className="primary-btn ml-1"
            >
              <Plus size={15} /> <span className="hidden sm:inline">Novo agendamento</span>
              <span className="sm:hidden">Novo</span>
            </button>
          </div>
        </header>
        <main className="mx-auto max-w-[1500px] px-4 py-6 sm:px-7 lg:px-9 lg:py-9">
          {page === 'dashboard' && (
            <Dashboard data={initialData} navigate={navigate} openModal={openModal} />
          )}
          {page === 'agenda' && <Agenda data={initialData} openModal={openModal} remove={remove} />}
          {page === 'clientes' && (
            <Clients data={initialData} openModal={openModal} remove={remove} />
          )}
          {page === 'servicos' && (
            <Services data={initialData} openModal={openModal} remove={remove} />
          )}
          {page === 'estoque' && (
            <Inventory data={initialData} openModal={openModal} remove={remove} />
          )}
          {page === 'financeiro' && (
            <Finance
              data={initialData}
              openModal={openModal}
              remove={remove}
              runAction={runAction}
            />
          )}
          {page === 'galeria' && <Gallery notify={notify} />}
          {page === 'divulgar' && (
            <ShareStudio user={initialData.user} share={shareAgenda} notify={notify} />
          )}
          {page === 'perfil' && <Profile user={initialData.user} openModal={openModal} />}
        </main>
      </div>
      {modal && (
        <AppModal
          kind={modal}
          editing={editing}
          data={initialData}
          pending={pending}
          close={closeModal}
          submit={submit}
        />
      )}
      {toast && (
        <div className="fixed bottom-5 left-1/2 z-[80] flex -translate-x-1/2 items-center gap-3 rounded-xl border border-[#42333b] bg-[#191719] px-5 py-3 text-sm shadow-2xl">
          <span className="flex size-6 items-center justify-center rounded-full bg-[#d72f77]">
            <Check size={14} />
          </span>
          {toast}
        </div>
      )}
    </div>
  )
}

function Sidebar({
  page,
  user,
  open,
  navigate,
  close,
  logout,
}: {
  page: Page
  user: UserData
  open: boolean
  navigate: (page: Page) => void
  close: () => void
  logout: () => void
}) {
  return (
    <>
      {open && (
        <button
          type="button"
          aria-label="Fechar menu"
          onClick={close}
          className="fixed inset-0 z-40 bg-black/70 lg:hidden"
        />
      )}
      <aside
        className={`studio-sidebar fixed inset-y-0 left-0 z-50 flex w-[250px] flex-col border-r transition-transform lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex h-[74px] items-center justify-between border-b border-white/[0.07] px-6">
          <button
            type="button"
            onClick={() => navigate('dashboard')}
            className="flex items-center gap-3 text-left"
          >
            <span className="flex size-9 items-center justify-center rounded-full border border-[#d72f77]/60 bg-[#24131c] font-serif text-xl italic text-[#ef5a9a]">
              A
            </span>
            <span>
              <strong className="block max-w-36 truncate font-serif text-base font-normal leading-none">
                {user.studioName.replace(' Studio', '')}
              </strong>
              <small className="text-[8px] uppercase tracking-[.24em] text-[#8e8589]">
                Nails Studio
              </small>
            </span>
          </button>
          <button
            type="button"
            aria-label="Fechar menu"
            onClick={close}
            className="text-[#9b9296] lg:hidden"
          >
            <X size={20} />
          </button>
        </div>
        <p className="px-6 pb-3 pt-7 text-[9px] font-semibold uppercase tracking-[.22em] text-[#665f62]">
          Gestão do estúdio
        </p>
        <nav className="space-y-1 px-3">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                type="button"
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm ${page === item.id ? 'bg-[#24151c] text-white' : 'text-[#91898d] hover:bg-white/[0.04] hover:text-white'}`}
              >
                <Icon size={17} className={page === item.id ? 'text-[#e44887]' : ''} />
                {item.label}
              </button>
            )
          })}
        </nav>
        <div className="mt-auto p-4">
          <button
            type="button"
            onClick={() => navigate('divulgar')}
            className={`mb-2 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm ${page === 'divulgar' ? 'bg-[#24151c] text-white' : 'text-[#91898d] hover:text-white'}`}
          >
            <Send size={17} />
            Divulgar agenda
          </button>
          <button
            type="button"
            onClick={() => navigate('perfil')}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm ${page === 'perfil' ? 'bg-[#24151c] text-white' : 'text-[#91898d] hover:text-white'}`}
          >
            <Settings size={17} />
            Perfil e configurações
          </button>
          <div className="mt-4 flex items-center gap-3 border-t border-white/[0.07] px-2 pt-5">
            <div className="flex size-9 items-center justify-center rounded-full bg-gradient-to-br from-[#e14a8a] to-[#6c2143] font-serif text-sm">
              {user.name
                .split(' ')
                .map((part) => part[0])
                .slice(0, 2)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-medium">{user.name}</p>
              <p className="text-[10px] text-[#716a6d]">Proprietária</p>
            </div>
            <button
              type="button"
              title="Sair"
              aria-label="Sair"
              onClick={logout}
              className="text-[#696164] hover:text-white"
            >
              <LogOut size={17} />
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}

function PageTitle({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string
  title: string
  description: string
  action?: React.ReactNode
}) {
  return (
    <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <p className="mb-2 text-[9px] font-bold uppercase tracking-[.26em] text-[#df4181]">
          {eyebrow}
        </p>
        <h1 className="font-serif text-3xl leading-tight sm:text-4xl">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm text-[#817a7d]">{description}</p>
      </div>
      {action}
    </div>
  )
}

function AddButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className="primary-btn shrink-0">
      <Plus size={15} />
      {children}
    </button>
  )
}

function Empty({
  icon: Icon,
  title,
  text,
  action,
}: {
  icon: ElementType
  title: string
  text: string
  action?: React.ReactNode
}) {
  return (
    <div className="flex min-h-64 flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 p-8 text-center">
      <span className="mb-4 flex size-12 items-center justify-center rounded-full bg-[#24151c] text-[#d94382]">
        <Icon size={22} />
      </span>
      <h3 className="font-serif text-xl">{title}</h3>
      <p className="mt-2 max-w-sm text-xs leading-5 text-[#756d70]">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

function Dashboard({
  data,
  navigate,
  openModal,
}: {
  data: StudioData
  navigate: (page: Page) => void
  openModal: (kind: ModalKind, value?: unknown) => void
}) {
  const paidIncome = sumTransactions(data.transactions, 'income', 'paid')
  const paidExpenses = sumTransactions(data.transactions, 'expense', 'paid')
  const today = new Date().toISOString().slice(0, 10)
  const todayAppointments = data.appointments.filter((item) => item.date.slice(0, 10) === today)
  const cards = [
    {
      label: 'Atendimentos',
      value: String(data.appointments.length),
      note: `${todayAppointments.length} hoje`,
      icon: ContactRound,
      color: 'text-[#de3e80]',
    },
    {
      label: 'Clientes',
      value: String(data.clients.length),
      note: 'cadastradas',
      icon: UsersRound,
      color: 'text-[#ad6384]',
    },
    {
      label: 'Receitas recebidas',
      value: money(paidIncome),
      note: 'lançamentos pagos',
      icon: BadgeDollarSign,
      color: 'text-[#d4a760]',
    },
    {
      label: 'Saldo atual',
      value: money(paidIncome - paidExpenses),
      note: `${money(paidExpenses)} em gastos`,
      icon: TrendingUp,
      color: 'text-[#5e9b88]',
    },
  ]
  return (
    <>
      <PageTitle
        eyebrow={new Intl.DateTimeFormat('pt-BR', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
        }).format(new Date())}
        title={`Olá, ${data.user.name.split(' ')[0]}.`}
        description="Seu talento, nossa organização. Veja como está o movimento do estúdio."
        action={<AddButton onClick={() => openModal('appointment')}>Novo agendamento</AddButton>}
      />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(({ label, value, note, icon: Icon, color }) => (
          <div key={label} className="panel p-5">
            <div className="mb-5 flex items-center justify-between">
              <span className="text-[9px] uppercase tracking-[.18em] text-[#716b6e]">{label}</span>
              <Icon size={17} className={color} />
            </div>
            <strong className="block font-serif text-2xl font-normal">{value}</strong>
            <span className="mt-2 block text-[9px] text-[#716b6e]">{note}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-4 xl:grid-cols-[1.4fr_.8fr]">
        <div className="panel p-5 sm:p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="section-kicker">Fluxo financeiro</p>
              <h2 className="font-serif text-xl">Receitas x despesas</h2>
            </div>
            <button
              type="button"
              onClick={() => navigate('financeiro')}
              className="text-xs text-[#8c8387] hover:text-white"
            >
              Ver financeiro <ArrowUpRight size={14} className="ml-1 inline" />
            </button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl bg-[#12201a] p-5">
              <ArrowUpRight className="text-[#65a890]" size={19} />
              <p className="mt-5 text-[9px] uppercase tracking-wider text-[#6d837a]">
                Entradas recebidas
              </p>
              <p className="mt-1 font-serif text-2xl">{money(paidIncome)}</p>
            </div>
            <div className="rounded-xl bg-[#211317] p-5">
              <ArrowDownLeft className="text-[#d36178]" size={19} />
              <p className="mt-5 text-[9px] uppercase tracking-wider text-[#8d7379]">
                Saídas pagas
              </p>
              <p className="mt-1 font-serif text-2xl">{money(paidExpenses)}</p>
            </div>
          </div>
        </div>
        <div className="panel p-5">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="section-kicker">Estoque</p>
              <h2 className="font-serif text-xl">Atenção necessária</h2>
            </div>
            <button
              type="button"
              onClick={() => navigate('estoque')}
              className="text-[#81777b] hover:text-white"
            >
              <ArrowUpRight size={16} />
            </button>
          </div>
          {data.products
            .filter((p) => p.currentStock <= p.minimumStock)
            .slice(0, 4)
            .map((product) => (
              <div
                key={product.id}
                className="flex items-center gap-3 border-b border-white/[0.06] py-3 last:border-0"
              >
                <span className="flex size-8 items-center justify-center rounded-lg bg-[#29171b] text-[#d65b70]">
                  <PackageMinus size={15} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs">{product.name}</p>
                  <p className="text-[9px] text-[#736a6e]">
                    {product.currentStock} {product.unit} restantes
                  </p>
                </div>
                <span className="rounded-full bg-[#29171b] px-2 py-1 text-[8px] text-[#d87989]">
                  baixo
                </span>
              </div>
            ))}
          {lowStockCount(data.products) === 0 && (
            <p className="py-8 text-center text-xs text-[#70686b]">
              Nenhum produto com estoque baixo.
            </p>
          )}
        </div>
      </div>
      <div className="mt-4 panel p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="section-kicker">Agenda</p>
            <h2 className="font-serif text-xl">Próximos horários</h2>
          </div>
          <button
            type="button"
            onClick={() => navigate('agenda')}
            className="text-xs text-[#8c8387] hover:text-white"
          >
            Ver agenda
          </button>
        </div>
        {data.appointments.length ? (
          <div className="grid gap-3 md:grid-cols-3">
            {data.appointments.slice(0, 3).map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => openModal('appointment', item)}
                className="rounded-xl border border-white/[0.07] bg-[#101011] p-4 text-left hover:border-[#d62e76]/30"
              >
                <p className="text-[9px] uppercase text-[#d84080]">
                  {dateLabel(item.date)} ·{' '}
                  {new Date(item.date).toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
                <p className="mt-2 text-sm">{item.clientName}</p>
                <p className="mt-1 text-[10px] text-[#726a6d]">
                  {item.serviceName} · {money(item.amount)}
                </p>
              </button>
            ))}
          </div>
        ) : (
          <p className="py-8 text-center text-xs text-[#70686b]">Sua agenda ainda está vazia.</p>
        )}
      </div>
    </>
  )
}

function Agenda({
  data,
  openModal,
  remove,
}: {
  data: StudioData
  openModal: (kind: ModalKind, value?: unknown) => void
  remove: (action: (data: FormData) => Promise<ActionResult>, id: string, label: string) => void
}) {
  const [cursor, setCursor] = useState(new Date())
  const monthLabel = new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(
    cursor,
  )
  const visible = data.appointments.filter((item) => {
    const date = new Date(item.date)
    return date.getMonth() === cursor.getMonth() && date.getFullYear() === cursor.getFullYear()
  })
  return (
    <>
      <PageTitle
        eyebrow="Organização do dia"
        title="Agenda"
        description="Crie, edite, acompanhe pagamentos e cancele horários."
        action={<AddButton onClick={() => openModal('appointment')}>Novo agendamento</AddButton>}
      />
      <div className="panel overflow-hidden">
        <div className="flex items-center justify-between border-b border-white/[0.07] p-5">
          <button
            type="button"
            aria-label="Mês anterior"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
            className="icon-btn"
          >
            <ChevronLeft size={16} />
          </button>
          <h2 className="font-serif text-xl capitalize">{monthLabel}</h2>
          <button
            type="button"
            aria-label="Próximo mês"
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
            className="icon-btn"
          >
            <ChevronRight size={16} />
          </button>
        </div>
        {visible.length ? (
          <div className="divide-y divide-white/[0.06]">
            {visible.map((item) => (
              <div
                key={item.id}
                className="grid gap-4 p-5 hover:bg-white/[0.02] sm:grid-cols-[100px_1fr_auto] sm:items-center"
              >
                <div>
                  <p className="font-serif text-lg">
                    {new Date(item.date).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                  <p className="text-[9px] text-[#71696c]">{dateLabel(item.date)}</p>
                </div>
                <div className="border-l border-[#d62e76]/40 pl-4">
                  <p className="text-sm">{item.clientName}</p>
                  <p className="mt-1 text-[10px] text-[#777074]">
                    {item.serviceName} · {money(item.amount)} · {paymentLabel(item.paymentStatus)}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    title="Editar"
                    onClick={() => openModal('appointment', item)}
                    className="icon-btn"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    type="button"
                    title="Excluir"
                    onClick={() => remove(deleteAppointmentAction, item.id, 'este agendamento')}
                    className="icon-btn hover:!text-red-400"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Empty
            icon={CalendarDays}
            title="Nenhum horário neste mês"
            text="Navegue entre os meses ou adicione um novo agendamento."
            action={<AddButton onClick={() => openModal('appointment')}>Agendar agora</AddButton>}
          />
        )}
      </div>
    </>
  )
}

function Clients({
  data,
  openModal,
  remove,
}: {
  data: StudioData
  openModal: (kind: ModalKind, value?: unknown) => void
  remove: (action: (data: FormData) => Promise<ActionResult>, id: string, label: string) => void
}) {
  const [query, setQuery] = useState('')
  const list = data.clients.filter(
    (item) => item.name.toLowerCase().includes(query.toLowerCase()) || item.phone.includes(query),
  )
  return (
    <>
      <PageTitle
        eyebrow="Relacionamento"
        title="Clientes"
        description="Histórico, preferências e informações para um atendimento mais pessoal."
        action={<AddButton onClick={() => openModal('client')}>Nova cliente</AddButton>}
      />
      <div className="panel overflow-hidden">
        <div className="flex items-center gap-3 border-b border-white/[0.07] p-4">
          <Search size={16} className="text-[#6f686b]" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar por nome ou telefone..."
            className="w-full bg-transparent text-sm outline-none placeholder:text-[#514b4e]"
          />
        </div>
        {list.length ? (
          <div className="divide-y divide-white/[0.06]">
            {list.map((client) => (
              <div
                key={client.id}
                className="grid gap-4 p-5 hover:bg-white/[0.02] sm:grid-cols-[1fr_150px_auto] sm:items-center"
              >
                <div className="flex items-center gap-3">
                  <span className="flex size-10 items-center justify-center rounded-full bg-[#25151d] font-serif text-[#dc4785]">
                    {client.name
                      .split(' ')
                      .map((part) => part[0])
                      .slice(0, 2)}
                  </span>
                  <div>
                    <p className="text-sm">{client.name}</p>
                    <p className="text-[10px] text-[#746c70]">
                      {client.phone}
                      {client.email ? ` · ${client.email}` : ''}
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-[#5f595c]">Atendimentos</p>
                  <p className="mt-1 text-xs">{client.visits}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    title="Editar"
                    onClick={() => openModal('client', client)}
                    className="icon-btn"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    type="button"
                    title="Excluir"
                    onClick={() => remove(deleteClientAction, client.id, client.name)}
                    className="icon-btn hover:!text-red-400"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Empty
            icon={UsersRound}
            title="Nenhuma cliente encontrada"
            text={
              query
                ? 'Tente buscar com outro nome ou telefone.'
                : 'Cadastre sua primeira cliente para começar.'
            }
            action={
              !query && <AddButton onClick={() => openModal('client')}>Cadastrar cliente</AddButton>
            }
          />
        )}
      </div>
    </>
  )
}

function Services({
  data,
  openModal,
  remove,
}: {
  data: StudioData
  openModal: (kind: ModalKind, value?: unknown) => void
  remove: (action: (data: FormData) => Promise<ActionResult>, id: string, label: string) => void
}) {
  return (
    <>
      <PageTitle
        eyebrow="Seu catálogo"
        title="Serviços e preços"
        description="Mantenha preços, duração e disponibilidade sempre atualizados."
        action={<AddButton onClick={() => openModal('service')}>Novo serviço</AddButton>}
      />
      {data.services.length ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {data.services.map((service) => (
            <div key={service.id} className={`panel p-5 ${!service.active ? 'opacity-60' : ''}`}>
              <div className="flex items-start justify-between">
                <span className="flex size-10 items-center justify-center rounded-full bg-[#25151d] text-[#db4181]">
                  <Sparkles size={17} />
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    title="Editar"
                    onClick={() => openModal('service', service)}
                    className="icon-btn"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    type="button"
                    title="Excluir"
                    onClick={() => remove(deleteServiceAction, service.id, service.name)}
                    className="icon-btn hover:!text-red-400"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
              <p className="mt-6 text-[9px] uppercase tracking-[.18em] text-[#766e72]">
                {service.category} · {service.active ? 'Ativo' : 'Inativo'}
              </p>
              <h2 className="mt-1 font-serif text-2xl">{service.name}</h2>
              <p className="mt-2 line-clamp-2 min-h-8 text-[10px] leading-4 text-[#70686c]">
                {service.description || 'Sem descrição.'}
              </p>
              <div className="mt-5 flex items-center justify-between border-t border-white/[0.07] pt-4">
                <span className="flex items-center gap-2 text-[10px] text-[#777074]">
                  <Clock3 size={13} /> {service.durationMinutes} min
                </span>
                <strong className="font-serif text-xl font-normal text-[#e04b8a]">
                  {money(service.price)}
                </strong>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <Empty
          icon={Scissors}
          title="Seu catálogo está vazio"
          text="Cadastre os serviços oferecidos, a duração e o preço."
          action={<AddButton onClick={() => openModal('service')}>Adicionar serviço</AddButton>}
        />
      )}
    </>
  )
}

function Inventory({
  data,
  openModal,
  remove,
}: {
  data: StudioData
  openModal: (kind: ModalKind, value?: unknown) => void
  remove: (action: (data: FormData) => Promise<ActionResult>, id: string, label: string) => void
}) {
  const totalValue = data.products.reduce(
    (sum, item) => sum + item.currentStock * item.costPrice,
    0,
  )
  return (
    <>
      <PageTitle
        eyebrow="Materiais e produtos"
        title="Controle de estoque"
        description="Acompanhe entradas, consumo, custo e reposição dos produtos de unha."
        action={
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => openModal('movement')}
              disabled={!data.products.length}
              className="secondary-btn"
            >
              <PackagePlus size={15} />
              Movimentar estoque
            </button>
            <AddButton onClick={() => openModal('product')}>Novo produto</AddButton>
          </div>
        }
      />
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <Metric
          icon={Box}
          label="Produtos cadastrados"
          value={String(data.products.length)}
          detail={`${lowStockCount(data.products)} com estoque baixo`}
        />
        <Metric
          icon={CircleDollarSign}
          label="Valor em estoque"
          value={money(totalValue)}
          detail="pelo custo de compra"
        />
        <Metric
          icon={PackageMinus}
          label="Itens em atenção"
          value={String(lowStockCount(data.products))}
          detail="no mínimo ou abaixo"
        />
      </div>
      {data.products.length ? (
        <div className="panel overflow-hidden">
          <div className="divide-y divide-white/[0.06]">
            {data.products.map((product) => {
              const low = product.currentStock <= product.minimumStock
              return (
                <div
                  key={product.id}
                  className="grid gap-4 p-5 sm:grid-cols-[1fr_130px_140px_auto] sm:items-center"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm">{product.name}</p>
                      {low && (
                        <span className="rounded-full bg-[#2b171c] px-2 py-1 text-[8px] text-[#db6c82]">
                          repor
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-[10px] text-[#746c70]">
                      {product.category}
                      {product.brand ? ` · ${product.brand}` : ''}
                      {product.supplier ? ` · ${product.supplier}` : ''}
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] uppercase text-[#5e585a]">Saldo atual</p>
                    <p className={`mt-1 font-serif text-lg ${low ? 'text-[#df5f77]' : ''}`}>
                      {product.currentStock} {product.unit}
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] uppercase text-[#5e585a]">Custo em estoque</p>
                    <p className="mt-1 text-xs">
                      {money(product.currentStock * product.costPrice)}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      title="Movimentar"
                      onClick={() => openModal('movement', product)}
                      className="icon-btn"
                    >
                      <PackagePlus size={15} />
                    </button>
                    <button
                      type="button"
                      title="Editar"
                      onClick={() => openModal('product', product)}
                      className="icon-btn"
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      type="button"
                      title="Excluir"
                      onClick={() => remove(deleteProductAction, product.id, product.name)}
                      className="icon-btn hover:!text-red-400"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ) : (
        <Empty
          icon={ShoppingBasket}
          title="Estoque vazio"
          text="Cadastre esmaltes, géis, tips, lixas e outros materiais do estúdio."
          action={<AddButton onClick={() => openModal('product')}>Cadastrar produto</AddButton>}
        />
      )}{' '}
      {data.movements.length > 0 && (
        <div className="mt-5 panel p-5">
          <p className="section-kicker">Histórico</p>
          <h2 className="font-serif text-xl">Últimas movimentações</h2>
          <div className="mt-4 divide-y divide-white/[0.06]">
            {data.movements.slice(0, 6).map((movement) => (
              <div key={movement.id} className="flex items-center gap-3 py-3">
                <span
                  className={`flex size-8 items-center justify-center rounded-full ${movement.type === 'in' ? 'bg-[#16241f] text-[#62a68e]' : 'bg-[#29171c] text-[#d76279]'}`}
                >
                  {movement.type === 'in' ? (
                    <ArrowDownLeft size={14} />
                  ) : (
                    <ArrowUpRight size={14} />
                  )}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs">{movement.productName}</p>
                  <p className="text-[9px] text-[#6d6568]">
                    {movement.description} · {dateLabel(movement.movementDate)}
                  </p>
                </div>
                <p className="text-xs">
                  {movement.type === 'out' ? '-' : '+'}
                  {movement.quantity}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  )
}

function Finance({
  data,
  openModal,
  remove,
  runAction,
}: {
  data: StudioData
  openModal: (kind: ModalKind, value?: unknown) => void
  remove: (action: (data: FormData) => Promise<ActionResult>, id: string, label: string) => void
  runAction: (
    action: (data: FormData) => Promise<ActionResult>,
    data: FormData,
    close?: boolean,
  ) => void
}) {
  const [filter, setFilter] = useState<'all' | 'income' | 'expense'>('all')
  const list = data.transactions.filter((item) => filter === 'all' || item.type === filter)
  const income = sumTransactions(data.transactions, 'income', 'paid')
  const expense = sumTransactions(data.transactions, 'expense', 'paid')
  const pending = data.transactions
    .filter((item) => item.status === 'pending')
    .reduce((sum, item) => sum + item.amount, 0)
  const markPaid = (recordId: string) => {
    const form = new FormData()
    form.set('id', recordId)
    runAction(markTransactionPaidAction, form, false)
  }
  return (
    <>
      <PageTitle
        eyebrow="Entradas e saídas"
        title="Controle financeiro"
        description="Saiba exatamente quanto recebeu, quanto gastou e o que ainda está pendente."
        action={<AddButton onClick={() => openModal('transaction')}>Novo lançamento</AddButton>}
      />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          icon={TrendingUp}
          label="Receitas recebidas"
          value={money(income)}
          detail="somente pagamentos pagos"
        />
        <Metric
          icon={TrendingDown}
          label="Despesas pagas"
          value={money(expense)}
          detail="gastos confirmados"
        />
        <Metric
          icon={WalletCards}
          label="Saldo"
          value={money(income - expense)}
          detail="receitas menos despesas"
        />
        <Metric icon={Clock3} label="Pendente" value={money(pending)} detail="a pagar ou receber" />
      </div>
      <div className="mt-5 panel overflow-hidden">
        <div className="flex flex-col justify-between gap-3 border-b border-white/[0.07] p-4 sm:flex-row sm:items-center">
          <div>
            <p className="section-kicker">Movimentações</p>
            <h2 className="font-serif text-xl">Histórico financeiro</h2>
          </div>
          <div className="flex rounded-lg bg-[#0c0c0d] p-1 text-[10px]">
            {(
              [
                ['all', 'Todos'],
                ['income', 'Receitas'],
                ['expense', 'Despesas'],
              ] as const
            ).map(([id, label]) => (
              <button
                type="button"
                key={id}
                onClick={() => setFilter(id)}
                className={`rounded-md px-3 py-2 ${filter === id ? 'bg-[#26151d] text-white' : 'text-[#777074]'}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        {list.length ? (
          <div className="divide-y divide-white/[0.06]">
            {list.map((item) => (
              <div
                key={item.id}
                className="grid gap-4 p-5 hover:bg-white/[0.02] sm:grid-cols-[1fr_140px_120px_auto] sm:items-center"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`flex size-9 items-center justify-center rounded-full ${item.type === 'income' ? 'bg-[#16241f] text-[#5da38a]' : 'bg-[#29171c] text-[#d76279]'}`}
                  >
                    {item.type === 'income' ? (
                      <ArrowUpRight size={16} />
                    ) : (
                      <ArrowDownLeft size={16} />
                    )}
                  </span>
                  <div>
                    <p className="text-sm">{item.description}</p>
                    <p className="mt-1 text-[9px] uppercase text-[#6c6568]">
                      {item.category} · {item.paymentMethod}
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-[9px] uppercase text-[#5f595c]">
                    {dateLabel(item.transactionDate)}
                  </p>
                  <p
                    className={`mt-1 font-serif text-lg ${item.type === 'income' ? 'text-[#72aa96]' : 'text-[#d8788b]'}`}
                  >
                    {item.type === 'income' ? '+' : '-'} {money(item.amount)}
                  </p>
                </div>
                <div>
                  {item.status === 'pending' ? (
                    <button
                      type="button"
                      onClick={() => markPaid(item.id)}
                      className="rounded-full bg-[#2a2415] px-3 py-1.5 text-[9px] text-[#c9a956] hover:bg-[#39301a]"
                    >
                      Marcar como pago
                    </button>
                  ) : (
                    <span className="rounded-full bg-[#17241f] px-3 py-1.5 text-[9px] text-[#67a891]">
                      Pago
                    </span>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    title="Editar"
                    onClick={() => openModal('transaction', item)}
                    className="icon-btn"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    type="button"
                    title="Excluir"
                    onClick={() =>
                      remove(deleteFinancialTransactionAction, item.id, item.description)
                    }
                    className="icon-btn hover:!text-red-400"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Empty
            icon={WalletCards}
            title="Nenhum lançamento"
            text="Registre uma receita, despesa ou pagamento para acompanhar seu caixa."
            action={<AddButton onClick={() => openModal('transaction')}>Novo lançamento</AddButton>}
          />
        )}
      </div>
    </>
  )
}

function Gallery({ notify }: { notify: (message: string) => void }) {
  const images = [
    { src: '/images/nails-pink.jpg', title: 'Rosa clássico', tag: 'Soft Gel' },
    { src: '/images/nails-art.jpg', title: 'Arte contemporânea', tag: 'Nail art' },
    { src: '/images/nail-polish.jpg', title: 'Detalhes do estúdio', tag: 'Inspiração' },
  ]
  return (
    <>
      <PageTitle
        eyebrow="Portfólio"
        title="Galeria de unhas"
        description="Use seus trabalhos como inspiração durante os atendimentos."
        action={
          <button
            type="button"
            onClick={() => {
              const text = 'Veja algumas inspirações do meu trabalho no Andrade Nails Studio.'
              if (navigator.share)
                navigator.share({ title: 'Galeria de unhas', text }).catch(() => null)
              else
                navigator.clipboard.writeText(text).then(() => notify('Texto da galeria copiado.'))
            }}
            className="primary-btn"
          >
            <Camera size={15} />
            Compartilhar galeria
          </button>
        }
      />
      <div className="grid auto-rows-[280px] gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {images.map((image, index) => (
          <article
            key={image.title}
            className={`group relative overflow-hidden rounded-2xl ${index === 0 ? 'sm:row-span-2' : ''}`}
          >
            <Image
              src={image.src}
              alt={image.title}
              fill
              sizes="(max-width: 768px) 100vw, 33vw"
              className="object-cover transition duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/5 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-5">
              <div>
                <p className="text-[9px] uppercase tracking-[.2em] text-[#f05b9a]">{image.tag}</p>
                <h2 className="mt-1 font-serif text-2xl">{image.title}</h2>
              </div>
              <button
                type="button"
                aria-label={`Favoritar ${image.title}`}
                onClick={() => notify(`${image.title} adicionada aos favoritos.`)}
                className="flex size-9 items-center justify-center rounded-full bg-black/50 text-white hover:bg-[#d62e76]"
              >
                <Heart size={16} />
              </button>
            </div>
          </article>
        ))}
      </div>
    </>
  )
}

function ShareStudio({
  user,
  share,
  notify,
}: {
  user: UserData
  share: () => void
  notify: (message: string) => void
}) {
  return (
    <>
      <PageTitle
        eyebrow="Divulgação"
        title="Agenda aberta"
        description="Compartilhe seus horários e transforme seguidores em clientes."
      />
      <div className="grid gap-5 lg:grid-cols-[1fr_420px]">
        <div className="panel p-6">
          <p className="section-kicker">Mensagem pronta</p>
          <h2 className="font-serif text-2xl">Convide suas clientes</h2>
          <textarea
            id="share-message"
            defaultValue={`Agenda aberta no ${user.studioName}!\nGaranta seu horário e venha cuidar das suas unhas comigo. Vagas limitadas.`}
            className="mt-6 min-h-40 w-full rounded-xl border border-white/10 bg-[#0d0d0e] p-4 text-sm leading-6 outline-none focus:border-[#d62e76]/60"
          />
          <div className="mt-5 flex flex-wrap gap-3">
            <button type="button" onClick={share} className="primary-btn">
              <MessageCircle size={15} />
              Compartilhar
            </button>
            <button
              type="button"
              onClick={() =>
                navigator.clipboard
                  .writeText(
                    (document.getElementById('share-message') as HTMLTextAreaElement).value,
                  )
                  .then(() => notify('Mensagem copiada.'))
              }
              className="secondary-btn"
            >
              <CreditCard size={15} />
              Copiar texto
            </button>
          </div>
        </div>
        <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-[#d62e76]/25 bg-[#150d11] p-8 text-center">
          <div className="absolute -right-20 -top-20 size-64 rounded-full bg-[#d62e76]/20 blur-3xl" />
          <div className="relative flex h-full flex-col items-center justify-center border border-white/10 p-7">
            <Sparkles size={24} className="text-[#e44b89]" />
            <p className="mt-7 text-[9px] uppercase tracking-[.3em] text-[#bd8aa0]">
              {user.studioName}
            </p>
            <h2 className="mt-4 font-serif text-4xl italic">
              Agenda
              <br />
              aberta
            </h2>
            <span className="my-6 h-px w-12 bg-[#d62e76]" />
            <p className="text-xs leading-5 text-[#a99da2]">
              Horários disponíveis.
              <br />
              Reserve o seu momento.
            </p>
            <button
              type="button"
              onClick={share}
              className="mt-8 rounded-full bg-[#d62e76] px-5 py-2 text-[9px] font-bold uppercase tracking-wider"
            >
              Compartilhar agora
            </button>
          </div>
        </div>
      </div>
    </>
  )
}

function Profile({
  user,
  openModal,
}: {
  user: UserData
  openModal: (kind: ModalKind, value?: unknown) => void
}) {
  return (
    <>
      <PageTitle
        eyebrow="Configurações"
        title="Seu perfil"
        description="Edite seus dados e a identidade exibida no painel."
        action={
          <button type="button" onClick={() => openModal('profile', user)} className="primary-btn">
            <Pencil size={15} />
            Editar perfil
          </button>
        }
      />
      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <div className="panel p-6 text-center">
          <div className="mx-auto flex size-24 items-center justify-center rounded-full bg-gradient-to-br from-[#e14a8a] to-[#5a1b38] font-serif text-3xl">
            {user.name
              .split(' ')
              .map((part) => part[0])
              .slice(0, 2)}
          </div>
          <h2 className="mt-5 font-serif text-2xl">{user.name}</h2>
          <p className="mt-1 text-xs text-[#7f767a]">{user.studioName}</p>
          <p className="mt-4 text-xs leading-5 text-[#766e72]">
            {user.bio || 'Adicione uma descrição sobre você e seu estúdio.'}
          </p>
        </div>
        <div className="panel p-6">
          <p className="section-kicker">Informações</p>
          <h2 className="font-serif text-xl">Dados da conta</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <ProfileItem label="Nome" value={user.name} />
            <ProfileItem label="Estúdio" value={user.studioName} />
            <ProfileItem label="E-mail de acesso" value={user.email} />
            <ProfileItem label="Telefone" value={user.phone || 'Não informado'} />
            <ProfileItem label="Instagram" value={user.instagram || 'Não informado'} />
          </div>
        </div>
      </div>
    </>
  )
}

function ProfileItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-b border-white/[0.06] pb-4">
      <p className="text-[9px] uppercase tracking-wider text-[#5f595c]">{label}</p>
      <p className="mt-2 text-sm">{value}</p>
    </div>
  )
}
function Metric({
  icon: Icon,
  label,
  value,
  detail,
}: {
  icon: ElementType
  label: string
  value: string
  detail: string
}) {
  return (
    <div className="panel p-5">
      <span className="flex size-9 items-center justify-center rounded-lg bg-[#24151c] text-[#df4383]">
        <Icon size={17} />
      </span>
      <p className="mt-5 text-[9px] uppercase tracking-[.16em] text-[#736b6f]">{label}</p>
      <p className="mt-1 font-serif text-2xl">{value}</p>
      <p className="mt-2 text-[9px] text-[#6b756f]">{detail}</p>
    </div>
  )
}

function AppModal({
  kind,
  editing,
  data,
  pending,
  close,
  submit,
}: {
  kind: Exclude<ModalKind, null>
  editing: unknown
  data: StudioData
  pending: boolean
  close: () => void
  submit: (event: FormEvent<HTMLFormElement>) => void
}) {
  const titles = {
    appointment: 'Agendamento',
    client: 'Cliente',
    service: 'Serviço',
    product: 'Produto',
    movement: 'Movimentação de estoque',
    transaction: 'Lançamento financeiro',
    profile: 'Editar perfil',
  }
  const appointment = editing as AppointmentData | null
  const client = editing as ClientData | null
  const service = editing as ServiceData | null
  const product = editing as ProductData | null
  const transaction = editing as TransactionData | null
  const profile = (editing as UserData | null) ?? data.user
  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center overflow-y-auto bg-black/80 p-4 backdrop-blur-sm"
      onMouseDown={close}
    >
      <div
        className="modal-card my-auto w-full max-w-xl rounded-2xl border p-6 shadow-2xl"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="mb-6 flex items-center justify-between">
          <div>
            <p className="section-kicker">{editing ? 'Editar' : 'Adicionar'}</p>
            <h2 className="font-serif text-2xl">{titles[kind]}</h2>
          </div>
          <button type="button" aria-label="Fechar" onClick={close} className="icon-btn">
            <X size={18} />
          </button>
        </div>
        <form onSubmit={submit} className="space-y-4">
          {Boolean(editing) && kind !== 'movement' && (
            <input type="hidden" name="id" value={(editing as { id?: string }).id ?? ''} />
          )}
          {kind === 'appointment' && (
            <>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Cliente">
                  <select name="client" required defaultValue={appointment?.clientId ?? ''}>
                    <option value="" disabled>
                      Selecione
                    </option>
                    {data.clients.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Serviço">
                  <select
                    name="service"
                    required
                    defaultValue={appointment?.serviceId ?? ''}
                    onChange={(event) => {
                      const selected = data.services.find((item) => item.id === event.target.value)
                      const amount = event.currentTarget.form?.elements.namedItem(
                        'amount',
                      ) as HTMLInputElement | null
                      if (selected && amount) amount.value = String(selected.price)
                    }}
                  >
                    <option value="" disabled>
                      Selecione
                    </option>
                    {data.services
                      .filter((item) => item.active)
                      .map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.name}
                        </option>
                      ))}
                  </select>
                </Field>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Data e horário">
                  <input
                    name="date"
                    type="datetime-local"
                    required
                    defaultValue={dateTimeInput(appointment?.date)}
                  />
                </Field>
                <Field label="Valor">
                  <input
                    name="amount"
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    defaultValue={appointment?.amount ?? 0}
                  />
                </Field>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Status">
                  <select name="status" defaultValue={appointment?.status ?? 'confirmed'}>
                    <option value="confirmed">Confirmado</option>
                    <option value="pending">Pendente</option>
                    <option value="completed">Concluído</option>
                    <option value="cancelled">Cancelado</option>
                  </select>
                </Field>
                <Field label="Pagamento">
                  <select
                    name="paymentStatus"
                    defaultValue={appointment?.paymentStatus ?? 'pending'}
                  >
                    <option value="pending">Pendente</option>
                    <option value="partial">Parcial</option>
                    <option value="paid">Pago</option>
                  </select>
                </Field>
              </div>
              <Field label="Forma de pagamento">
                <select name="paymentMethod" defaultValue={appointment?.paymentMethod ?? 'pix'}>
                  <option value="pix">Pix</option>
                  <option value="dinheiro">Dinheiro</option>
                  <option value="cartao">Cartão</option>
                  <option value="transferencia">Transferência</option>
                  <option value="outro">Outro</option>
                </select>
              </Field>
              <Field label="Observações">
                <textarea
                  name="notes"
                  defaultValue={appointment?.notes}
                  placeholder="Detalhes do atendimento..."
                />
              </Field>
            </>
          )}
          {kind === 'client' && (
            <>
              <Field label="Nome completo">
                <input name="name" required defaultValue={client?.name} />
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="WhatsApp">
                  <input
                    name="phone"
                    required
                    defaultValue={client?.phone}
                    placeholder="(11) 99999-9999"
                  />
                </Field>
                <Field label="E-mail">
                  <input name="email" type="email" defaultValue={client?.email} />
                </Field>
              </div>
              <Field label="Preferências">
                <textarea
                  name="preferences"
                  defaultValue={client?.preferences}
                  placeholder="Cores, formatos e estilos favoritos..."
                />
              </Field>
              <Field label="Observações">
                <textarea name="notes" defaultValue={client?.notes} />
              </Field>
            </>
          )}
          {kind === 'service' && (
            <>
              <Field label="Nome do serviço">
                <input name="name" required defaultValue={service?.name} />
              </Field>
              <div className="grid gap-3 sm:grid-cols-3">
                <Field label="Categoria">
                  <input name="category" required defaultValue={service?.category} />
                </Field>
                <Field label="Duração (min)">
                  <input
                    name="durationMinutes"
                    type="number"
                    min="5"
                    required
                    defaultValue={service?.durationMinutes ?? 60}
                  />
                </Field>
                <Field label="Preço">
                  <input
                    name="price"
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    defaultValue={service?.price ?? 0}
                  />
                </Field>
              </div>
              <Field label="Descrição">
                <textarea name="description" defaultValue={service?.description} />
              </Field>
              <label className="flex items-center gap-3 text-xs text-[#9a9094]">
                <input
                  type="checkbox"
                  name="active"
                  defaultChecked={service?.active ?? true}
                  className="accent-[#d62e76]"
                />
                Serviço disponível para agendamento
              </label>
            </>
          )}
          {kind === 'product' && (
            <>
              <Field label="Nome do produto">
                <input name="name" required defaultValue={product?.name} />
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Categoria">
                  <input
                    name="category"
                    required
                    defaultValue={product?.category}
                    placeholder="Gel, esmalte, descartável..."
                  />
                </Field>
                <Field label="Marca">
                  <input name="brand" defaultValue={product?.brand} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Field label="Unidade">
                  <select name="unit" defaultValue={product?.unit ?? 'un'}>
                    <option value="un">Unidade</option>
                    <option value="ml">ml</option>
                    <option value="g">g</option>
                    <option value="caixa">Caixa</option>
                  </select>
                </Field>
                <Field label="Saldo atual">
                  <input
                    name="currentStock"
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    defaultValue={product?.currentStock ?? 0}
                  />
                </Field>
                <Field label="Estoque mínimo">
                  <input
                    name="minimumStock"
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    defaultValue={product?.minimumStock ?? 1}
                  />
                </Field>
                <Field label="Custo unitário">
                  <input
                    name="costPrice"
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    defaultValue={product?.costPrice ?? 0}
                  />
                </Field>
              </div>
              <Field label="Fornecedor">
                <input name="supplier" defaultValue={product?.supplier} />
              </Field>
            </>
          )}
          {kind === 'movement' && (
            <>
              <Field label="Produto">
                <select
                  name="product"
                  required
                  defaultValue={(editing as ProductData | null)?.id ?? ''}
                >
                  <option value="" disabled>
                    Selecione
                  </option>
                  {data.products.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} — saldo {item.currentStock} {item.unit}
                    </option>
                  ))}
                </select>
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Tipo">
                  <select name="type" defaultValue="in">
                    <option value="in">Entrada</option>
                    <option value="out">Saída / consumo</option>
                    <option value="adjustment">Ajuste de saldo</option>
                  </select>
                </Field>
                <Field label="Quantidade">
                  <input name="quantity" type="number" step="0.01" min="0.01" required />
                </Field>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Custo unitário">
                  <input
                    name="unitCost"
                    type="number"
                    step="0.01"
                    min="0"
                    defaultValue={(editing as ProductData | null)?.costPrice ?? 0}
                  />
                </Field>
                <Field label="Data">
                  <input
                    name="movementDate"
                    type="datetime-local"
                    required
                    defaultValue={dateTimeInput()}
                  />
                </Field>
              </div>
              <Field label="Motivo / descrição">
                <input
                  name="description"
                  required
                  placeholder="Compra, uso em atendimento, correção..."
                />
              </Field>
              <label className="flex items-center gap-3 text-xs text-[#9a9094]">
                <input type="checkbox" name="recordExpense" className="accent-[#d62e76]" />
                Registrar esta entrada também como despesa financeira
              </label>
              <Field label="Forma de pagamento da compra">
                <select name="paymentMethod" defaultValue="pix">
                  <option value="pix">Pix</option>
                  <option value="dinheiro">Dinheiro</option>
                  <option value="cartao">Cartão</option>
                  <option value="transferencia">Transferência</option>
                  <option value="outro">Outro</option>
                </select>
              </Field>
            </>
          )}
          {kind === 'transaction' && (
            <>
              <Field label="Descrição">
                <input
                  name="description"
                  required
                  defaultValue={transaction?.description}
                  placeholder="Ex.: Atendimento Soft Gel ou compra de materiais"
                />
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Tipo">
                  <select name="type" defaultValue={transaction?.type ?? 'income'}>
                    <option value="income">Receita — dinheiro que entrou</option>
                    <option value="expense">Despesa — dinheiro que saiu</option>
                  </select>
                </Field>
                <Field label="Categoria">
                  <select name="category" defaultValue={transaction?.category ?? 'servico'}>
                    <option value="servico">Serviço</option>
                    <option value="produto">Produto</option>
                    <option value="materiais">Materiais</option>
                    <option value="aluguel">Aluguel</option>
                    <option value="contas">Contas</option>
                    <option value="marketing">Marketing</option>
                    <option value="outros">Outros</option>
                  </select>
                </Field>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Valor">
                  <input
                    name="amount"
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    defaultValue={transaction?.amount}
                  />
                </Field>
                <Field label="Data">
                  <input
                    name="transactionDate"
                    type="datetime-local"
                    required
                    defaultValue={dateTimeInput(transaction?.transactionDate)}
                  />
                </Field>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Situação">
                  <select name="transactionStatus" defaultValue={transaction?.status ?? 'paid'}>
                    <option value="paid">Pago / recebido</option>
                    <option value="pending">Pendente</option>
                  </select>
                </Field>
                <Field label="Forma de pagamento">
                  <select name="paymentMethod" defaultValue={transaction?.paymentMethod ?? 'pix'}>
                    <option value="pix">Pix</option>
                    <option value="dinheiro">Dinheiro</option>
                    <option value="cartao">Cartão</option>
                    <option value="transferencia">Transferência</option>
                    <option value="outro">Outro</option>
                  </select>
                </Field>
              </div>
              <Field label="Observações">
                <textarea name="notes" defaultValue={transaction?.notes} />
              </Field>
            </>
          )}
          {kind === 'profile' && (
            <>
              <Field label="Seu nome">
                <input name="name" required defaultValue={profile.name} />
              </Field>
              <Field label="Nome do estúdio">
                <input name="studioName" required defaultValue={profile.studioName} />
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Telefone">
                  <input name="phone" defaultValue={profile.phone} />
                </Field>
                <Field label="Instagram">
                  <input
                    name="instagram"
                    defaultValue={profile.instagram}
                    placeholder="@seuperfil"
                  />
                </Field>
              </div>
              <Field label="Sobre você e o estúdio">
                <textarea name="bio" defaultValue={profile.bio} />
              </Field>
            </>
          )}
          <button
            disabled={
              pending || (kind === 'appointment' && (!data.clients.length || !data.services.length))
            }
            className="mt-2 w-full rounded-lg bg-[#d62e76] py-3 text-xs font-semibold hover:bg-[#e63d84] disabled:cursor-not-allowed disabled:opacity-50"
          >
            {pending ? 'Salvando...' : 'Salvar alterações'}
          </button>
          {kind === 'appointment' && (!data.clients.length || !data.services.length) && (
            <p className="text-center text-[10px] text-[#d78a9e]">
              Cadastre ao menos uma cliente e um serviço antes de agendar.
            </p>
          )}
        </form>
      </div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="form-field">
      <span>{label}</span>
      {children}
    </label>
  )
}
function lowStockCount(products: ProductData[]) {
  return products.filter((item) => item.currentStock <= item.minimumStock).length
}
function sumTransactions(
  transactions: TransactionData[],
  type: 'income' | 'expense',
  status: 'paid' | 'pending',
) {
  return transactions
    .filter((item) => item.type === type && item.status === status)
    .reduce((sum, item) => sum + item.amount, 0)
}
function paymentLabel(status: AppointmentData['paymentStatus']) {
  return status === 'paid' ? 'Pago' : status === 'partial' ? 'Parcial' : 'Pendente'
}
