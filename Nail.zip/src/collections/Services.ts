import type { CollectionConfig } from 'payload'
import { appUserOnly, ownDocuments, preventDeleteWhenReferenced, setOwner } from '@/access/appUser'

export const Services: CollectionConfig = {
  slug: 'services',
  admin: {
    group: 'Estúdio',
    useAsTitle: 'name',
    defaultColumns: ['name', 'category', 'price', 'active'],
  },
  access: { create: appUserOnly, read: ownDocuments, update: ownDocuments, delete: ownDocuments },
  hooks: {
    beforeValidate: [setOwner],
    beforeDelete: [
      preventDeleteWhenReferenced(
        'appointments',
        'service',
        'Este serviço possui agendamentos vinculados.',
      ),
    ],
  },
  fields: [
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      index: true,
      admin: { hidden: true },
    },
    { name: 'name', type: 'text', required: true },
    { name: 'category', type: 'text', required: true },
    { name: 'durationMinutes', type: 'number', required: true, min: 5 },
    { name: 'price', type: 'number', required: true, min: 0 },
    { name: 'description', type: 'textarea' },
    { name: 'active', type: 'checkbox', defaultValue: true },
  ],
}
