import type { CollectionConfig } from 'payload'
import { appUserOnly, ownDocuments, setOwner, validateOwnedRelationships } from '@/access/appUser'

export const StockMovements: CollectionConfig = {
  slug: 'stock-movements',
  admin: {
    group: 'Estoque',
    useAsTitle: 'description',
    defaultColumns: ['product', 'type', 'quantity', 'movementDate'],
  },
  access: { create: appUserOnly, read: ownDocuments, update: () => false, delete: () => false },
  hooks: {
    beforeValidate: [
      setOwner,
      validateOwnedRelationships([{ field: 'product', collection: 'products' }]),
    ],
  },
  fields: [
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      index: true,
      admin: { hidden: true },
    },
    { name: 'product', type: 'relationship', relationTo: 'products', required: true },
    {
      name: 'type',
      type: 'select',
      required: true,
      options: [
        { label: 'Entrada', value: 'in' },
        { label: 'Saída', value: 'out' },
        { label: 'Ajuste', value: 'adjustment' },
      ],
    },
    { name: 'quantity', type: 'number', required: true, min: 0.01 },
    { name: 'unitCost', type: 'number', min: 0 },
    { name: 'movementDate', type: 'date', required: true },
    { name: 'description', type: 'text', required: true },
  ],
}
