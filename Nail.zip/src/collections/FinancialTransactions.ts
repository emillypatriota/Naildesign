import type { CollectionConfig } from 'payload'
import { appUserOnly, ownDocuments, setOwner, validateOwnedRelationships } from '@/access/appUser'

export const FinancialTransactions: CollectionConfig = {
  slug: 'financial-transactions',
  admin: {
    group: 'Financeiro',
    useAsTitle: 'description',
    defaultColumns: ['description', 'type', 'amount', 'status', 'transactionDate'],
  },
  access: { create: appUserOnly, read: ownDocuments, update: ownDocuments, delete: ownDocuments },
  hooks: {
    beforeValidate: [
      setOwner,
      validateOwnedRelationships([{ field: 'appointment', collection: 'appointments' }]),
    ],
  },
  fields: [
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      index: true,
      admin: { hidden: true },
    },
    { name: 'description', type: 'text', required: true },
    {
      name: 'type',
      type: 'select',
      required: true,
      options: [
        { label: 'Receita', value: 'income' },
        { label: 'Despesa', value: 'expense' },
      ],
    },
    {
      name: 'category',
      type: 'select',
      required: true,
      options: ['servico', 'produto', 'materiais', 'aluguel', 'contas', 'marketing', 'outros'],
    },
    { name: 'amount', type: 'number', required: true, min: 0.01 },
    { name: 'transactionDate', type: 'date', required: true, index: true },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'paid',
      options: [
        { label: 'Pago', value: 'paid' },
        { label: 'Pendente', value: 'pending' },
      ],
    },
    {
      name: 'paymentMethod',
      type: 'select',
      options: ['pix', 'dinheiro', 'cartao', 'transferencia', 'outro'],
    },
    { name: 'appointment', type: 'relationship', relationTo: 'appointments' },
    { name: 'notes', type: 'textarea' },
  ],
}
