import config from '@payload-config'
import { getPayload } from 'payload'
import { getCurrentUser } from '@/lib/app-auth'
import { AuthScreen } from './components/AuthScreen'
import { StudioApp } from './components/StudioApp'

export default async function HomePage() {
  const user = await getCurrentUser()
  if (!user) return <AuthScreen />

  const payload = await getPayload({ config })
  const options = { user, overrideAccess: false as const, limit: 100, pagination: false as const }
  const [clients, services, appointments, products, movements, transactions] = await Promise.all([
    payload.find({ collection: 'clients', ...options, sort: 'name' }),
    payload.find({ collection: 'services', ...options, sort: 'name' }),
    payload.find({ collection: 'appointments', ...options, sort: 'date', depth: 1 }),
    payload.find({ collection: 'products', ...options, sort: 'name' }),
    payload.find({ collection: 'stock-movements', ...options, sort: '-movementDate', depth: 1 }),
    payload.find({ collection: 'financial-transactions', ...options, sort: '-transactionDate' }),
  ])

  return (
    <StudioApp
      initialData={{
        user: {
          id: String(user.id),
          name: user.name,
          studioName: user.studioName,
          email: user.email,
          phone: user.phone ?? '',
          instagram: user.instagram ?? '',
          bio: user.bio ?? '',
        },
        clients: clients.docs.map((item) => ({
          id: String(item.id),
          name: item.name,
          phone: item.phone,
          email: item.email ?? '',
          preferences: item.preferences ?? '',
          notes: item.notes ?? '',
          visits: item.visits ?? 0,
          lastVisit: item.lastVisit ?? '',
        })),
        services: services.docs.map((item) => ({
          id: String(item.id),
          name: item.name,
          category: item.category,
          durationMinutes: item.durationMinutes,
          price: item.price,
          description: item.description ?? '',
          active: item.active !== false,
        })),
        appointments: appointments.docs.map((item) => ({
          id: String(item.id),
          title: item.title,
          clientId: typeof item.client === 'object' ? String(item.client.id) : String(item.client),
          clientName: typeof item.client === 'object' ? item.client.name : 'Cliente',
          serviceId:
            typeof item.service === 'object' ? String(item.service.id) : String(item.service),
          serviceName: typeof item.service === 'object' ? item.service.name : 'Serviço',
          date: item.date,
          status: item.status,
          paymentStatus: item.paymentStatus,
          paymentMethod: item.paymentMethod ?? 'pix',
          amount: item.amount,
          notes: item.notes ?? '',
        })),
        products: products.docs.map((item) => ({
          id: String(item.id),
          name: item.name,
          category: item.category,
          brand: item.brand ?? '',
          unit: item.unit,
          currentStock: item.currentStock,
          minimumStock: item.minimumStock,
          costPrice: item.costPrice,
          supplier: item.supplier ?? '',
        })),
        movements: movements.docs.map((item) => ({
          id: String(item.id),
          productName: typeof item.product === 'object' ? item.product.name : 'Produto',
          type: item.type,
          quantity: item.quantity,
          unitCost: item.unitCost ?? 0,
          movementDate: item.movementDate,
          description: item.description,
        })),
        transactions: transactions.docs.map((item) => ({
          id: String(item.id),
          description: item.description,
          type: item.type,
          category: item.category,
          amount: item.amount,
          transactionDate: item.transactionDate,
          status: item.status,
          paymentMethod: item.paymentMethod ?? 'outro',
          notes: item.notes ?? '',
        })),
      }}
    />
  )
}
