import type { CollectionConfig } from 'payload'
import { appUserOnly, ownDocuments, preventDeleteWhenReferenced, setOwner } from '@/access/appUser'

export const Products: CollectionConfig = {
  slug: 'products',
  admin: {
    group: 'Estoque',
    useAsTitle: 'name',
    defaultColumns: ['name', 'category', 'currentStock', 'minimumStock'],
  },
  access: { create: appUserOnly, read: ownDocuments, update: ownDocuments, delete: ownDocuments },
  hooks: {
    beforeValidate: [setOwner],
    beforeDelete: [
      preventDeleteWhenReferenced(
        'stock-movements',
        'product',
        'Este produto possui movimentações de estoque.',
      ),
    ],
  },
  fields: [
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      index: true,
      admin: { hidden: true },
    },
    { name: 'name', type: 'text', required: true },
    { name: 'category', type: 'text', required: true },
    { name: 'brand', type: 'text' },
    {
      name: 'unit',
      type: 'select',
      required: true,
      defaultValue: 'un',
      options: ['un', 'ml', 'g', 'caixa'],
    },
    { name: 'currentStock', type: 'number', required: true, defaultValue: 0, min: 0 },
    { name: 'minimumStock', type: 'number', required: true, defaultValue: 1, min: 0 },
    { name: 'costPrice', type: 'number', required: true, defaultValue: 0, min: 0 },
    { name: 'supplier', type: 'text' },
  ],
}
